<template>
  <p>
    <router-link to="/">HOME</router-link>
    <router-link to="/list">사원목록</router-link>
  </p>
</template>
<script>
export default {
  name: 'NavHeader',
};
</script>
