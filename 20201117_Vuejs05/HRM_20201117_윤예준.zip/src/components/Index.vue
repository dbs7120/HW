<template>
  <div>
    <div>
      <h1 class="text-center">메인 페이지</h1>
    </div>
    <div>
      만든이: YYJ
    </div>
  </div>
</template>

<script>
export default {
  name: 'index',
};
</script>
